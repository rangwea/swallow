---
author: "xianmin"
title: "no header, no toc"
date: 2022-02-20
tags: [
    "toc",
    "golang",
    "templates",
    "themes",
    "development",
]
categories: [
    "Development",
    "golang",
    "index",
]
---

This tutorial will show you how to create a simple theme in Hugo. I assume that you are familiar with HTML, the bash command line, and that you are comfortable using Markdown to format content. I'll explain how Hugo uses templates and how you can organize your templates to create a theme. I won't cover using CSS to style your theme.

