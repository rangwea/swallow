---
title: "{{ replace .Name "-" " " | title }}"
image: 
style:
    background: "#2a9d8f"
    color: "#fff"
---